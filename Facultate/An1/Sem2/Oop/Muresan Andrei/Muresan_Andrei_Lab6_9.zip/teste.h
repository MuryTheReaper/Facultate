#pragma once

void test_add();

void test_remove();

void test_modify();

void test_filter();

void test_sort();

void test_validate();

void test_all();

void test_vector();

void test_contract();