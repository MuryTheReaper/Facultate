#include "tests.h"
#include <iostream>

int main(int argc, char **argv){
    
    test_all();
    std::cout<<"END\n";
    return 0;
}
