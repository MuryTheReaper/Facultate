#ifndef TESTS_H
#define TESTS_H

void test_all();

void test_read();

void test_filter();

#endif // TESTS_H
