#include <iostream>

#include "TestExtins.h"
#include "TestScurt.h"

int main() {
  testAll();
  testAllExtins();
  std::cout << "Finished Tests!" << std::endl;
}
