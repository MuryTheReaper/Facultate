package domain;

public class Confidential extends Entity<Long> {
    private String username;
    private String password;
    private Long userId;

    public Confidential(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public Confidential(String username, String password, Long userId) {
        this.userId = userId;
        this.username = username;
        this.password = password;
    }

    public Confidential(Long id, String username, String password, Long userId) {
        this.userId = userId;
        this.username = username;
        this.password = password;
        this.setId(id);
    }


    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public Long getUserId() {
        return userId;
    }
}
