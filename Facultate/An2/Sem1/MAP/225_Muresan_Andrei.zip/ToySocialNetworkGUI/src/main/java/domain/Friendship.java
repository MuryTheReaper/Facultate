package domain;


import java.time.LocalDateTime;

/**
 * Class that represents a friendship between two Entities.
 */
public class Friendship extends Entity<Long>{

    private Long id1;
    private Long id2;
    private LocalDateTime date;

    public Friendship(Long id1, Long id2, LocalDateTime date) {
        this.id1 = id1;
        this.id2 = id2;
        this.date = date;
    }

    public Friendship(Long id, Long id1, Long id2, LocalDateTime date) {
        this.setId(id);
        this.id1 = id1;
        this.id2 = id2;
        this.date = date;
    }

    public LocalDateTime getDate() {
        return date;
    }

    public void setDate(LocalDateTime date) {
        this.date = date;
    }

    public Long getId1() {
        return id1;
    }

    public void setId1(Long id1) {
        this.id1 = id1;
    }

    public Long getId2() {
        return id2;
    }

    public void setId2(Long id2) {
        this.id2 = id2;
    }

    @Override
    public String toString() {
        return "Friendship{" +
                "id1=" + id1 +
                ", id2=" + id2 +
                '}';
    }
}
