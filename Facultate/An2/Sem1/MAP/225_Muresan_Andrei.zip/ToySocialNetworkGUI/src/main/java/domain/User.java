package domain;

import java.util.List;
import java.util.Objects;

/**
 * Class that represents a user.
 */
public class User extends Entity<Long> {
    private String firstName;
    private String lastName;
    private List<User> friends;

    public User(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public User(String firstName, String lastName, List<User> friends) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.friends = friends;
    }

    public User(Long ID,String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.setId(ID);
    }


    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public List<User> getFriends() {
        return friends;
    }

    @Override
    public String toString() {
        return "User{" +
                "firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof User that)) return false;

        if(getFriends() == null && that.getFriends() == null)
            return getFirstName().equals(that.getFirstName()) &&
                    getLastName().equals(that.getLastName());
        else if(getFriends() == null || that.getFriends() == null)
            return false;
        else
            return getFirstName().equals(that.getFirstName()) &&
                    getLastName().equals(that.getLastName()) &&
                    getFriends().equals(that.getFriends());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getFirstName(), getLastName(), getFriends());
    }
}
