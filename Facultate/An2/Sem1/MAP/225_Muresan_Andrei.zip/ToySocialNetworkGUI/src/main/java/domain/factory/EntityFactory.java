package domain.factory;

import domain.*;
import utils.Constants;

import java.time.LocalDateTime;
import java.util.List;

public class EntityFactory<ID, E extends Entity<ID>> implements Factory<ID, E> {

    private static EntityFactory singleton = null;

    private EntityFactory() {
    }

    public synchronized static EntityFactory getInstance() {
        if (singleton == null) {
            singleton = new EntityFactory();
        }
        return singleton;
    }

    @Override
    public E createEntity(Class<E> strategy, List<String> attributes) {
        if(strategy == User.class && attributes.size() == 2) {
            return (E) new User(attributes.get(0), attributes.get(1));
        } else if (strategy == User.class && attributes.size() == 3) {
            return (E) new User(Long.parseLong(attributes.get(0)), attributes.get(1), attributes.get(2));
        } else if (strategy == Friendship.class && attributes.size() == 3) {
            return (E) new Friendship(Long.parseLong(attributes.get(0)), Long.parseLong(attributes.get(1)), LocalDateTime.parse(attributes.get(2), Constants.formatter));
        } else if (strategy == Friendship.class && attributes.size() == 4) {
            return (E) new Friendship(Long.parseLong(attributes.get(0)), Long.parseLong(attributes.get(1)), Long.parseLong(attributes.get(2)), LocalDateTime.parse(attributes.get(3), Constants.formatter));
        } else if (strategy == Confidential.class && attributes.size() == 3) {
            return (E) new Confidential(attributes.get(0),attributes.get(1),Long.parseLong(attributes.get(2)));
        } else if (strategy == Confidential.class && attributes.size() == 4) {
            return (E) new Confidential(Long.parseLong(attributes.get(0)),attributes.get(1), attributes.get(2), Long.parseLong(attributes.get(3)));
        } else if (strategy == Message.class && attributes.size() == 3) {
            return (E) new Message(attributes.get(0), Long.parseLong(attributes.get(1)), Long.parseLong(attributes.get(2)));
        }
        return null;
    }
}
