package domain.validators;

import domain.Confidential;

public class ConfidentialValidator implements Validator<Confidential> {
    @Override
    public void validate(Confidential entity) throws ValidatorException {
        if (entity.getUsername().equals(""))
            throw new ValidatorException("Username can't be empty");
        if (entity.getPassword().equals(""))
            throw new ValidatorException("Password can't be empty");
    }
}
