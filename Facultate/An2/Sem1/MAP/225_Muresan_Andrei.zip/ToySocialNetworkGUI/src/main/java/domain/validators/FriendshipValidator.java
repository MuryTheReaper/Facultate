package domain.validators;

import domain.Friendship;

public class FriendshipValidator implements Validator<Friendship> {
    @Override
    public void validate(Friendship entity) throws ValidatorException {
        if (entity.getId1() == null || entity.getId2() == null) {
            throw new ValidatorException("Id1 and Id2 must not be null!");
        }
        if (entity.getId1().equals(entity.getId2())) {
            throw new ValidatorException("Id1 and Id2 must not be equal!");
        }
    }
}
