package domain.validators;


import domain.Message;

public class MessageValidator implements Validator<Message> {
    @Override
    public void validate(Message entity) throws ValidatorException {
        if (entity.getText().equals(""))
            throw new ValidatorException("Message can't be empty");
    }
}
