package domain.validators;

import domain.User;

public class UserValidator implements Validator<User> {
    @Override
    public void validate(User entity) throws ValidatorException {
        String errors = "";
        if (entity.getFirstName().equals(""))
            errors += "First name can't be empty!\n";
        if (entity.getLastName().equals(""))
            errors += "Last name can't be empty!\n";
        if(entity.getFirstName().length() < 3)
            errors += "First name must have at least 3 characters!\n";
        if (entity.getFirstName().length() > 50)
            errors += "First name can't be longer than 50 characters!\n";
        if(entity.getLastName().length() < 3)
            errors += "Last name must have at least 3 characters!\n";
        if (entity.getLastName().length() > 50)
            errors += "Last name can't be longer than 50 characters!\n";
        if (entity.getFirstName().length()>0 && !Character.isUpperCase(entity.getFirstName().charAt(0)))
            errors += "First name must start with an uppercase letter!\n";
        if (entity.getLastName().length()>0 && !Character.isUpperCase(entity.getLastName().charAt(0)))
            errors += "Last name must start with an uppercase letter!\n";
        if (!entity.getFirstName().matches("[a-zA-Z]+"))
            errors += "First name must contain only letters!\n";
        if (!entity.getLastName().matches("[a-zA-Z]+"))
            errors += "Last name must contain only letters!\n";
        /*if (entity.getFirstName().matches(".*\\d.*"))
            errors += "First name can't contain digits!\n";
        if (entity.getLastName().matches(".*\\d.*"))
            errors += "Last name can't contain digits!\n";
        */if(entity.getFirstName().matches(".*\\s.*"))
            errors += "First name can't contain spaces!\n";
        if(entity.getLastName().matches(".*\\s.*"))
            errors += "Last name can't contain spaces!\n";
        if (!errors.equals(""))
            throw new ValidatorException(errors);
    }
}
