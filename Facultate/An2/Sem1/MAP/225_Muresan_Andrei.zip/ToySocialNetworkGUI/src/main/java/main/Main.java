package main;

import config.ApplicationContext;
import domain.validators.ConfidentialValidator;
import domain.validators.MessageValidator;
import repository.database.ConfidentialDBRepository;
import repository.database.MessageDBRepository;
import service.*;
import ui.LoginPageController;
import domain.validators.FriendshipValidator;
import domain.validators.UserValidator;
import repository.database.FriendshipDBRepository;
import repository.database.UserDBRepository;
import ui.Console;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;

public class Main extends Application{
    public static void main(String[] args) throws IOException {

        //runApplication();
        launch(args);
    }

    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("/pages/loginPage.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 600, 400);
        LoginPageController ctrl = fxmlLoader.getController();
        ctrl.setService(createMasterServiceDB());
        stage.setTitle("Login Screen");
        stage.setScene(scene);
        stage.show();
    }

    private static void runApplication() throws IOException {
        System.out.println("Starting........");

        MasterService masterServiceFile = createMasterServiceDB();

        Console console = new Console(masterServiceFile);

        console.run();
    }

    private static MasterService createMasterServiceDB() {
        return new MasterService(
                new UserService(new UserDBRepository(
                        ApplicationContext.getPROPERTIES().getProperty("databaseURL"),
                        ApplicationContext.getPROPERTIES().getProperty("databaseUser"),
                        ApplicationContext.getPROPERTIES().getProperty("databasePassword"),
                        new UserValidator()))
                ,new FriendshipService(
                    new FriendshipDBRepository(
                        ApplicationContext.getPROPERTIES().getProperty("databaseURL"),
                        ApplicationContext.getPROPERTIES().getProperty("databaseUser"),
                        ApplicationContext.getPROPERTIES().getProperty("databasePassword"),
                        new FriendshipValidator())),
                new ConfidentialService(new ConfidentialDBRepository(
                        ApplicationContext.getPROPERTIES().getProperty("databaseURL"),
                        ApplicationContext.getPROPERTIES().getProperty("databaseUser"),
                        ApplicationContext.getPROPERTIES().getProperty("databasePassword"),
                        new ConfidentialValidator())),
                new MessageService(new MessageDBRepository(
                        ApplicationContext.getPROPERTIES().getProperty("databaseURL"),
                        ApplicationContext.getPROPERTIES().getProperty("databaseUser"),
                        ApplicationContext.getPROPERTIES().getProperty("databasePassword"),
                        new MessageValidator())));

    }
}

