package repository.database;

import domain.Confidential;
import domain.validators.Validator;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ConfidentialDBRepository extends AbstractDBRepository<Long, Confidential> {

    public ConfidentialDBRepository(String url, String username, String password, Validator<Confidential> validator) {
        super(url, username, password, validator);
    }

    @Override
    public Confidential extractEntity(ResultSet rs) {

        try {
            Long id = rs.getLong("id");
            Long userId = rs.getLong("userId");
            String username = rs.getString("username");
            String password = rs.getString("password");
            boolean isDeleted = rs.getBoolean("isDeleted");
            Confidential confidential = new Confidential(username, password);
            confidential.setId(id);
            confidential.setUserId(userId);
            confidential.setDeleted(isDeleted);
            return confidential;

        }catch (SQLException e){
            e.printStackTrace();
        }
        return null;

    }

    @Override
    public void createEntity(PreparedStatement ps, Confidential entity) {

        try {
            ps.setString(1, entity.getUsername());
            ps.setString(2, entity.getPassword());
            ps.setLong(3, entity.getUserId());
            ps.setLong(4, entity.getId());

        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    @Override
    public String getUpdateQuery() {
        return "UPDATE \"Confidential\" SET \"username\" = ?, \"password\" = ?, \"userId\" = ? ,\"isDeleted\" = false WHERE \"id\" = ?";
    }

    @Override
    public String getInsertQuery() {
        return "INSERT INTO \"Confidential\" (\"username\", \"password\", \"userId\", \"id\") VALUES (?, ?, ?, ?)";
    }

    @Override
    public Class<Confidential> getEntityClass() {
        return Confidential.class;
    }
}
