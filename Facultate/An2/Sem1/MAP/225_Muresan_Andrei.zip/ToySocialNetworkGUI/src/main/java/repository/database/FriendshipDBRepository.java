package repository.database;

import domain.Friendship;
import domain.validators.Validator;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;

public class FriendshipDBRepository extends AbstractDBRepository<Long, Friendship> {

    public FriendshipDBRepository(String url, String username, String password, Validator<Friendship> validator) {
        super(url, username, password, validator);
    }

    @Override
    public Friendship extractEntity(ResultSet rs) {

        try {
            Long id = rs.getLong("id");
            Long id1 = rs.getLong("id1");
            Long id2 = rs.getLong("id2");
            boolean isDeleted = rs.getBoolean("isDeleted");
            LocalDateTime date = rs.getTimestamp("date").toLocalDateTime();
            Friendship friendship = new Friendship(id1, id2, date);
            friendship.setId(id);
            friendship.setDeleted(isDeleted);
            return friendship;

        }catch (SQLException e){
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public void createEntity(PreparedStatement ps, Friendship entity) {

        try {
            ps.setLong(1, entity.getId1());
            ps.setLong(2, entity.getId2());
            ps.setTimestamp(3, Timestamp.valueOf(entity.getDate()));
            ps.setLong(4, entity.getId());

        }catch (SQLException e){
            e.printStackTrace();
        }

    }

    @Override
    public String getUpdateQuery() {
        return "UPDATE \"Friendship\" SET \"id1\" = ?, \"id2\" = ?, \"date\" = ?,\"isDeleted\" = false WHERE \"id\" = ?";
    }

    @Override
    public String getInsertQuery() {
        return "INSERT INTO \"Friendship\" (\"id1\", \"id2\", \"date\", \"id\") VALUES (?, ?, ?, ?)";
    }

    @Override
    public Class<Friendship> getEntityClass() {
        return Friendship.class;
    }
}

