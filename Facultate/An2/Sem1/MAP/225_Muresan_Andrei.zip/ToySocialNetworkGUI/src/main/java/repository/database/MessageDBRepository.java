package repository.database;

import domain.Message;
import domain.validators.Validator;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class MessageDBRepository extends AbstractDBRepository<Long, Message> {

    public MessageDBRepository(String url, String username, String password, Validator<Message> validator) {
        super(url, username, password, validator);
    }

    @Override
    public Message extractEntity(ResultSet rs) {

        try {
            Long id = rs.getLong("id");
            String text = rs.getString("text");
            Long from = rs.getLong("from");
            Long to = rs.getLong("to");
            boolean isDeleted = rs.getBoolean("isDeleted");
            Message message = new Message(text, from, to);
            message.setId(id);
            message.setDeleted(isDeleted);
            return message;

        }catch (SQLException e){
            e.printStackTrace();
        }
        return null;

    }

    @Override
    public void createEntity(PreparedStatement ps, Message entity) {

        try {
            ps.setString(1, entity.getText());
            ps.setLong(2, entity.getFrom());
            ps.setLong(3, entity.getTo());
            ps.setLong(4, entity.getId());

        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    @Override
    public String getUpdateQuery() {
        return "UPDATE \"Message\" SET \"text\" = ?, \"from\" = ?, \"to\" = ? ,\"isDeleted\" = false WHERE \"id\" = ?";
    }

    @Override
    public String getInsertQuery() {
        return "INSERT INTO \"Message\" (\"text\", \"from\", \"to\", \"id\") VALUES (?, ?, ?, ?)";
    }

    @Override
    public Class<Message> getEntityClass() {
        return Message.class;
    }
}
