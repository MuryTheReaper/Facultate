package repository.database;

import domain.User;
import domain.validators.Validator;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserDBRepository extends AbstractDBRepository<Long, User> {

    public UserDBRepository(String url, String user, String password, Validator<User> validator) {
        super(url, user, password, validator);
    }


    @Override
    public String getInsertQuery() {
        return "INSERT INTO \"User\" (\"firstName\", \"lastName\", \"id\") VALUES (?, ?, ?)";
    }

    @Override
    public String getUpdateQuery() {
        return "UPDATE \"User\" SET \"firstName\" = ?, \"lastName\" = ?, \"isDeleted\" = false WHERE \"id\" = ?";
}

    @Override
    public User extractEntity(ResultSet rs) {

        try {
            Long id = rs.getLong("id");
            String firstName = rs.getString("firstName");
            String lastName = rs.getString("lastName");
            boolean isDeleted = rs.getBoolean("isDeleted");
            User user = new User(firstName, lastName);
            user.setId(id);
            user.setDeleted(isDeleted);
            return user;

        }catch (SQLException e){
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public void createEntity(PreparedStatement ps, User entity) {

        try {
            ps.setString(1, entity.getFirstName());
            ps.setString(2, entity.getLastName());
            ps.setLong(3, entity.getId());

        } catch (SQLException e) {
            e.printStackTrace();
        }

    }


    @Override
    public Class<User> getEntityClass() {
        return User.class;
    }
}
