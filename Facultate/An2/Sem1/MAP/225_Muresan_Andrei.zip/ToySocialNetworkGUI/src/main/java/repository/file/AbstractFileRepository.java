package repository.file;

import domain.Entity;
import domain.validators.Validator;
import domain.validators.ValidatorException;
import repository.memory.InMemoryRepository;

import java.io.*;
import java.util.Arrays;
import java.util.List;

import static java.lang.System.exit;

public abstract class AbstractFileRepository<ID, E extends Entity<ID>> extends InMemoryRepository<ID, E> {

    private final String fileName;

    public AbstractFileRepository(Validator<E> validator, String fileName) {
        super(validator);
        this.fileName = fileName;
        loadData();
    }

    /**
     * Loads entity data from file
     * If the file is corrupted, the application will exit
     */
    private void loadData() {
        try(BufferedReader reader = new BufferedReader(new FileReader(fileName))){
            String line;
            while((line = reader.readLine()) != null){
                List<String> attributes = Arrays.asList(line.split(";"));
                //if(attributes.get(attributes.size()-1).equals("false")) {
                    E entity = extractEntity(attributes);

                    super.save(entity);
                //}
            }
        } catch (IOException e){
            e.printStackTrace();
        }catch (ValidatorException e){
            System.out.println("CORRUPTED FILE");
            System.out.println("CLOSING APPLICATION");
            exit(1);
        }
    }

    protected void writeToFile(E entity){
        try(BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, true))){
            writer.write(createEntityAsString(entity));
            writer.newLine();
        } catch (IOException e){
            e.printStackTrace();
        }
    }


    /**
     * Writes ALL entity data to file
     * @param entities to be written
     */
    protected void saveToFile(Iterable<E> entities){
        try(BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, false))){
            entities.forEach(entity ->{
                try {
                    writer.write(createEntityAsString(entity));
                    writer.newLine();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            });
        } catch (IOException e){
            e.printStackTrace();
        }
    }

    /**
     * Extracts an entity from a list of strings
     * @param attributes list of strings
     * @return entity
     */
    public abstract E extractEntity(List<String> attributes);

    /**
     * Creates a string representation of an entity
     * @param entity to be converted
     * @return string representation
     */
    protected abstract String createEntityAsString(E entity);

    @Override
    public E save(E entity){
        E e = super.save(entity);
        if(e == null){
            //writeToFile(entity);
            saveToFile(super.findTrueAll());
        }
        return e;
    }

    @Override
    public E delete(ID id){
        E e = super.delete(id);
        if(e != null){
            //writeToFile(e);
            saveToFile(super.findTrueAll());
        }
        return e;
    }

    @Override
    public E update(E entity){
        E e = super.update(entity);
        if(e == null){
            //writeToFile(entity);
            saveToFile(super.findTrueAll());
        }
        return e;
    }

}
