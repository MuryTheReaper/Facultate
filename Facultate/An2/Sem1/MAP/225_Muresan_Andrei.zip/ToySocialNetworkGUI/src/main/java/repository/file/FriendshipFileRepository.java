package repository.file;

import domain.Friendship;
import domain.validators.Validator;
import utils.Constants;

import java.time.LocalDateTime;
import java.util.List;

public class FriendshipFileRepository extends AbstractFileRepository<Long, Friendship> {

    public FriendshipFileRepository(Validator<Friendship> validator, String fileName) {
        super(validator, fileName);
    }

    @Override
    public Friendship extractEntity(List<String> attributes) {

        Friendship friendship = new Friendship(Long.parseLong(attributes.get(1)),
                Long.parseLong(attributes.get(2)), LocalDateTime.parse(attributes.get(3), Constants.formatter));
        friendship.setId(Long.parseLong(attributes.get(0)));
        friendship.setDeleted(Boolean.parseBoolean(attributes.get(4)));
        return friendship;
    }

    @Override
    protected String createEntityAsString(Friendship entity) {
        return entity.getId() + ";" + entity.getId1() + ";"
                + entity.getId2() + ";" + entity.getDate().format(Constants.formatter) + ";" + entity.isDeleted();
    }

    @Override
    public Class<Friendship> getEntityClass() {
        return Friendship.class;
    }
}
