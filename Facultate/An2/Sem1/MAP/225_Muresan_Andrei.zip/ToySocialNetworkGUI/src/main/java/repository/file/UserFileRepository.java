package repository.file;

import domain.User;
import domain.validators.Validator;

import java.util.List;

public class UserFileRepository extends AbstractFileRepository<Long, User> {

    public UserFileRepository(Validator<User> validator, String fileName) {
        super(validator, fileName);
    }

    @Override
    public User extractEntity(List<String> attributes) {

        User user = new User(attributes.get(1), attributes.get(2));
        user.setId(Long.parseLong(attributes.get(0)));
        user.setDeleted(Boolean.parseBoolean(attributes.get(3)));
        return user;
    }

    @Override
    protected String createEntityAsString(User entity) {
        return entity.getId() + ";" + entity.getFirstName() + ";" + entity.getLastName() + ";" + entity.isDeleted();
    }

    @Override
    public Class<User> getEntityClass() {
        return User.class;
    }
}
