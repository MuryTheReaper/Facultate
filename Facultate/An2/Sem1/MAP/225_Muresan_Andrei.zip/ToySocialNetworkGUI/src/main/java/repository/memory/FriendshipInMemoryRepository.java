package repository.memory;

import domain.Friendship;
import domain.validators.Validator;

public class FriendshipInMemoryRepository extends InMemoryRepository<Long, Friendship> {

    public FriendshipInMemoryRepository(Validator<Friendship> validator) {
        super(validator);
    }

    public Class<Friendship> getEntityClass() {
        return Friendship.class;
    }
}
