package repository.memory;

import domain.Entity;
import domain.validators.Validator;
import repository.Repository;
import repository.RepositoryException;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public abstract class InMemoryRepository<ID, E extends Entity<ID>> implements Repository<ID, E> {

    private final Validator<E> validator;
    Map<ID, E> entities;

    public InMemoryRepository(Validator<E> validator) {
        this.validator = validator;
        entities = new HashMap<ID, E>();
    }

    @Override
    public E findOne(ID id) {
        if (id == null)
            throw new RepositoryException("id must be not null");
        E entity = entities.get(id);
        if(entity!= null && entity.isDeleted())
            return null;
        return entity;
    }

    @Override
    public Iterable<E> findAll() {
        Collection<E> entities = this.entities.values();
        Collection<E> result = new ArrayList<E>();
        entities.forEach(entity -> {
            if(!entity.isDeleted())
                result.add(entity);
        });
        return result;
    }

    @Override
    public Iterable<E> findTrueAll() {
        return new ArrayList<E>(this.entities.values());
    }

    @Override
    public E save(E entity) {
        if (entity == null)
            throw new RepositoryException("entity must be not null");
        validator.validate(entity);
        E entitySave = entities.get(entity.getId());
        if (entitySave != null) {
            if(entitySave.isDeleted()) {
                entitySave.setDeleted(false);
                return null;
            }
            return entity;
        } else entities.put(entity.getId(), entity);
        return null;
    }

    @Override
    public E delete(ID id) throws RepositoryException{
        if (id == null)
            throw new RepositoryException("id must be not null");
        E entity = entities.get(id);
        entity.setDeleted(true);
        return entity;
    }

    @Override
    public E update(E entity) {

        if (entity == null)
            throw new RepositoryException("entity must be not null!");
        validator.validate(entity);

        entities.put(entity.getId(), entity);

        if (entities.get(entity.getId()) != null) {
            entities.put(entity.getId(), entity);
            return null;
        }
        return entity;

    }

    public abstract Class<E> getEntityClass();

}
