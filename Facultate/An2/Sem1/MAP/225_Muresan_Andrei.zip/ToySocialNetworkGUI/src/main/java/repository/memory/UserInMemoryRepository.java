package repository.memory;

import domain.User;
import domain.validators.Validator;

public class UserInMemoryRepository extends InMemoryRepository<Long, User> {

    public UserInMemoryRepository(Validator<User> validator) {
        super(validator);
    }

    @Override
    public Class<User> getEntityClass() {
        return User.class;
    }

}
