package service;

import domain.Confidential;
import repository.Repository;

import java.util.Collection;

public class ConfidentialService extends BasicService<Long, Confidential> {

    public ConfidentialService(Repository repository) {
        super(repository);
    }

    @Override
    public Long getNextId() {
        Collection<Confidential> all = (Collection<Confidential>) findTrueAll();
        Long max = 0L;
        for (Confidential entity : all) {
            if (entity.getId() > max )
                max = entity.getId();
        }
        return max+1;
    }
}
