package service;

import domain.Friendship;
import repository.Repository;
import utils.Graph;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class FriendshipService extends BasicService<Long, Friendship> {
    public FriendshipService(Repository repository) {
        super(repository);
    }

    @Override
    public Long getNextId() {
        Collection<Friendship> all = (Collection<Friendship>) findTrueAll();
        Long max = 0L;
        for (Friendship entity : all) {
            if (entity.getId() > max)
                max = entity.getId();
        }
        return max+1;
    }

    /**
     * Creates a graph of friendships from the repository
     * @return the graph of friendships
     */
    public Graph getGraph() {
        List<Friendship> edges = (List<Friendship>) findAll();
        List<Integer> users = new ArrayList<>();
        for(Friendship f : edges){
            users.add(f.getId1().intValue());
            users.add(f.getId2().intValue());
        }
        List<Integer> finalUsers = users.stream().distinct().toList();
        Graph graph = new Graph(finalUsers.size()+1);
        edges.forEach(edge -> graph.addEdge(finalUsers.indexOf(edge.getId1().intValue())+1, finalUsers.indexOf(edge.getId2().intValue())+1));
        return graph;
    }

    /**
     * Gets the number of connected components in the graph of friendships
     * @return the number of connected components
     */
    public int getNumberOfConnectedComponents() {
        return getGraph().getNumberOfConnectedComponents();
    }


    /**
     * Gets a list of lists of users IDs that are in the same connected component
     * @return the list of lists of users IDs
     */
    public ArrayList<ArrayList<Integer>> getCommunities(){
        return getGraph().DFS();
    }

}

