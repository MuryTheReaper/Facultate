package service;

import domain.Confidential;
import domain.Friendship;
import domain.Message;
import domain.User;
import utils.Constants;
import utils.Graph;

import java.time.LocalDateTime;
import java.util.*;

public class MasterService {

    private final UserService userService;
    private final FriendshipService friendshipService;
    private final ConfidentialService confidentialService;

    private final MessageService messageService;

    public MasterService(UserService userService, FriendshipService friendshipService,
                         ConfidentialService confidentialService, MessageService messageService) {
        this.userService = userService;
        this.friendshipService = friendshipService;
        this.confidentialService = confidentialService;
        this.messageService = messageService;
    }

    /**
     * Gets a user by name
     * @param firstName the first name of the user
     * @param lastName the last name of the user
     * @return the user or null if it doesn't exist
     */
    private User getUser(String firstName, String lastName) {
        List<User> all = (List<User>) userService.findAll();
        for (User user : all) {
            if (user.getFirstName().equals(firstName) && user.getLastName().equals(lastName))
                return user;
        }
        return null;
    }

    public User getUserById(Long id) {
        return userService.findOne(id);
    }

    /**
     * Gets all users
     * @return the list of users
     */
    public Iterable<User> getAllUsers() {
        return userService.findAll();
    }

    /**
     * Adds a user to the repository
     * @param firstName the first name of the user
     * @param lastName the last name of the user
     * @throws ServiceException if the user already exists
     */
    public void addUser(String firstName, String lastName) {
        if(getUser(firstName, lastName) != null)
            throw new ServiceException("User already exists!");

        List<String> attributes = new ArrayList<>();
        userService.findTrueAll().forEach(user -> {
            if(user.getFirstName().equals(firstName) && user.getLastName().equals(lastName) && user.isDeleted()) {
                attributes.add(user.getId().toString());
            }
        });

        attributes.add(firstName);
        attributes.add(lastName);
        userService.save(attributes);
    }

    /**
     * Generates a list of all the users that contain the given string in their name
     * @param firstName the first name of the user
     * @param lastName the last name of the user
     * @return the list of users as strings
     */
    public List<String> findPotentialUser(String firstName, String lastName) {

        Iterable<User> users = userService.findAll();
        List<String> potentialUser = new ArrayList<>();
        users.forEach(user -> {
            if (user.getFirstName().contains(firstName) && user.getLastName().contains(lastName)) {
                potentialUser.add(user + "||" + user.getId());
            }
        });

        return potentialUser;
    }

    /**
     * Removes a user from the repository and all the friendships that contain it
     * @param id the id of the user
     */
    public void removeUser(String id) {
        Long TheId = Long.parseLong(id);
        userService.delete(TheId);
        List<Friendship> friendships = (List<Friendship>) getFriendship(TheId);
        friendships.forEach(friendship -> friendshipService.delete(friendship.getId()));

    }

    /**
     * Updates a user
     * @param id the id of the user
     * @param firstName the new first name of the user
     * @param lastName the new last name of the user
     */

    public void updateUser(String id, String firstName, String lastName) {
        userService.update(List.of(id, firstName, lastName));
    }

    /**
     * Gets a friendship by id
     * @param id1 the id of the first user
     * @param id2 the id of the second user
     * @return the friendship or null if it doesn't exist
     */
    private Friendship getFriendship(Long id1, Long id2) {
        List<Friendship> all = (List<Friendship>) friendshipService.findAll();
        for (Friendship friendship : all) {
            if (friendship.getId1().equals(id1) && friendship.getId2().equals(id2))
                return friendship;
        }
        return null;
    }

    /**
     * Gets all friendships that contain a given user by id
     * @param id the id of the user
     * @return the list of friendships
     */
    private Iterable<Friendship> getFriendship(Long id) {
        List<Friendship> all = (List<Friendship>) friendshipService.findAll();
        List<Friendship> friendships = new ArrayList<>();
        for (Friendship friendship : all) {
            if (friendship.getId1().equals(id) || friendship.getId2().equals(id))
                friendships.add(friendship);
        }
        return friendships;
    }

    /**
     * Gets all the friendships in the repository
     * @return the list of friendships
     */
    public Iterable<String> getAllFriendships() {
        Iterable<Friendship> all = friendshipService.findAll();
        List<String> friendships = new ArrayList<>();
        Iterator<Friendship> it = all.iterator();
        while(it.hasNext()) {
            Friendship friendship = it.next();
            User user1 = userService.findOne(friendship.getId1());
            User user2 = userService.findOne(friendship.getId2());
            friendships.add(user1 + " --- " + user2 + " from " + friendship.getDate().format(Constants.formatter));
            it.next();
        }

        return  friendships;
    }

    /**
     * Adds a friendship to the repository
     * @param firstUser the first user
     * @param secondUser the second user
     * @throws ServiceException if the friendship already exists or if the users don't exist
     */
    public void addFriendship(List<String> firstUser, List<String> secondUser) {

        User user1 = getUser(firstUser.get(0), firstUser.get(1));
        User user2 = getUser(secondUser.get(0), secondUser.get(1));
        LocalDateTime now = LocalDateTime.now();
        String time = now.format(Constants.formatter);

        if(user1 == null || user2 == null) {
            throw new ServiceException("One of the users does not exist!");
        }

        if(getFriendship(user1.getId(), user2.getId()) != null) {
            throw new ServiceException("Friendship already exists!");
        }

        friendshipService.save(List.of(user1.getId().toString(), user2.getId().toString(), time));
        friendshipService.save(List.of(user2.getId().toString(), user1.getId().toString(), time));
    }

    /**
     * Removes a friendship from the repository
     * @param firstUser List of string that contains the attributes of the first user
     * @param secondUser List of string that contains the attributes of the second user
     * @throws ServiceException if the friendship doesn't exist or if the users don't exist
     */
    public void removeFriendship(List<String> firstUser, List<String> secondUser) {

        User user1 = getUser(firstUser.get(0), firstUser.get(1));
        User user2 = getUser(secondUser.get(0), secondUser.get(1));


        if(user1 == null || user2 == null) {
            throw new ServiceException("One of the users does not exist!");
        }

        Friendship friendship1 = getFriendship(user1.getId(), user2.getId());
        Friendship friendship2 = getFriendship(user2.getId(), user1.getId());

        if(friendship1 == null || friendship2 == null) {
            throw new ServiceException("Friendship does not exist!");
        }

        friendshipService.delete(friendship1.getId());
        friendshipService.delete(friendship2.getId());
    }

    /**
     * Updates a friendship
     * @param firstUser List of string that contains the attributes of the first user
     * @param secondUser List of string that contains the attributes of the second user
     * @param newUser List of string that contains the attributes of the new user that will replace the second one
     */
    public void updateFriendship(List<String> firstUser, List<String> secondUser, List<String> newUser){

        User user1 = getUser(firstUser.get(0), firstUser.get(1));
        User user2 = getUser(secondUser.get(0), secondUser.get(1));
        User userNew = getUser(newUser.get(0), newUser.get(1));

        if(user1 == null || user2 == null || userNew == null) {
            throw new ServiceException("One of the users does not exist!");
        }

        Friendship friendship1 = getFriendship(user1.getId(), user2.getId());
        Friendship friendship2 = getFriendship(user2.getId(), user1.getId());

        if(friendship1 == null || friendship2 == null) {
            throw new ServiceException("Friendship does not exist!");
        }

        friendshipService.update(List.of(friendship1.getId().toString(), user1.getId().toString(),
                userNew.getId().toString(), friendship1.getDate().format(Constants.formatter)));
        friendshipService.update(List.of(friendship2.getId().toString(), userNew.getId().toString(),
                user1.getId().toString(), friendship2.getDate().format(Constants.formatter)));

    }

    /**
     * Gets the number of communities that exists in the repository
     * @return the number of communities
     */
    public int getNumberOfCommunities() {
        return friendshipService.getNumberOfConnectedComponents();
    }

    /**
     * Gets the community that has the longest friendship chain
     * @return the list of users in the community as strings
     */
    public List<String> getMostSociableCommunity() {
        ArrayList<ArrayList<Integer>> communities = friendshipService.getCommunities();
        ArrayList<Integer> theOne = null;

        List<Friendship> list = (List<Friendship>) friendshipService.findAll();
        List<Integer> ids = new ArrayList<>();
        for(Friendship f: list) {
            ids.add(f.getId1().intValue());
            ids.add(f.getId2().intValue());
        }

        List<Integer> finalIds = ids.stream().distinct().toList();
        Dictionary<Integer, Integer> realIds = new Hashtable<>();
        for(ArrayList<Integer> small : communities) {
            for(Integer i : small) {
                realIds.put(i, finalIds.get(i-1));
            }
        }

        int max = 0;


        for(ArrayList<Integer> community : communities) {
            Graph graph = new Graph(community.size()+1);

            Dictionary<Integer, Integer> dictionary = new Hashtable<>();
            int count = 1;
            for (Integer id : community) {
                dictionary.put(realIds.get(id), count);
                count++;
            }
            for(Integer user: community){
                List<Friendship> friendships = (List<Friendship>) getFriendship(Long.valueOf(realIds.get(user)));
                for(Friendship friendship : friendships) {
                    if(user < friendship.getId2().intValue()) {
                        graph.addEdge(dictionary.get(friendship.getId1().intValue()), dictionary.get(friendship.getId2().intValue()));
                        graph.addEdge(dictionary.get(friendship.getId2().intValue()), dictionary.get(friendship.getId1().intValue()));
                    }
                }
            }
            int l = graph.getLongestPath();
            if(l > max){
                max = l;
                theOne = community;
            }
        }
        if (theOne == null) {
            throw new ServiceException("No communities found!");
        }
        List<String> result = new ArrayList<>();
        for(Integer user : theOne) {
            result.add(userService.findOne(Long.valueOf(realIds.get(user))).toString());
        }
        return result;
    }

    private Confidential getConfidential(String username, String password) {
        List<Confidential> all = (List<Confidential>) confidentialService.findAll();
        for (Confidential conf : all) {
            if (conf.getUsername().equals(username) && conf.getPassword().equals(password))
                return conf;
        }
        return null;
    }
    public void registerUser(String username, String password, String firstName, String lastName) {

        if (getConfidential(username, password) != null) {
            throw new ServiceException("Confidential already exists!");
        }

        this.addUser(firstName, lastName);
        Long id = Objects.requireNonNull(getUser(firstName, lastName)).getId();

        List<String> attributes = new ArrayList<>();
        confidentialService.findTrueAll().forEach(confidential -> {
            if(confidential.getUsername().equals(username) && confidential.getPassword().equals(password) && confidential.isDeleted()) {
                attributes.add(confidential.getId().toString());
            }
        });

        attributes.add(username);
        attributes.add(password);
        attributes.add(id.toString());
        confidentialService.save(attributes);

    }

    public User login(String username, String password) {
        Confidential confidential = getConfidential(username, password);

        if (confidential == null) {
            throw new ServiceException("Username or Password does not exist!");
        }

        return userService.findOne(confidential.getUserId());

    }

    public void sendFriendRequest(User userFrom, User userTo){

        String time = LocalDateTime.now().format(Constants.formatter);

        Friendship from = getFriendship(userTo.getId(), userFrom.getId());
        Friendship to = getFriendship(userFrom.getId(), userTo.getId());

        if(to == null && from == null) {
            friendshipService.save(List.of(userFrom.getId().toString(), userTo.getId().toString(), time));
        }
        else if (to != null && from == null) {
            throw new ServiceException("Friendship request already sent!");
        } else if (to == null) {
            throw new ServiceException("Accept the friendship request instead!");
        } else {
            throw new ServiceException("Friendship already exists!");
        }

    }

    private List<List<Friendship>> getFriendshipSentReceived (User user){
        List<Friendship> friendships = (List<Friendship>) getFriendship(user.getId());

        List<Friendship> sent = new ArrayList<>(friendships.stream().filter(friendship -> friendship.getId1().equals(user.getId())).toList());
        List<Friendship> received = new ArrayList<>(friendships.stream().filter(friendship -> friendship.getId2().equals(user.getId())).toList());
        List<Friendship> both = new ArrayList<>();

        for(Friendship friendship1 : sent) {
            for (Friendship friendship2 : received) {
                if (friendship1.getId2().equals(friendship2.getId1())) {
                    both.add(friendship1);
                    both.add(friendship2);
                }
            }
        }

        return List.of(sent, received, both);
    }

    public List<List<Friendship>> findFriendRequests(User user) {

        List<List<Friendship>> friendships = getFriendshipSentReceived(user);

        for(Friendship friendship : friendships.get(2)) {
            friendships.get(0).remove(friendship);
            friendships.get(1).remove(friendship);
        }

        List<List<Friendship>> result = new ArrayList<>();
        result.add(friendships.get(0));
        result.add(friendships.get(1));

        return result;

    }

    public void acceptFriendRequest(User userFrom, User userTo) {

        String time = LocalDateTime.now().format(Constants.formatter);
        friendshipService.save(List.of(userTo.getId().toString(), userFrom.getId().toString(), time));
        Friendship friendship = getFriendship(userFrom.getId(), userTo.getId());
        friendshipService.update(List.of(friendship.getId().toString(),userFrom.getId().toString(), userTo.getId().toString(), time));

    }

    public void denyFriendRequest(Friendship friendship) {
        friendshipService.delete(friendship.getId());
    }

    public List<Friendship> findFriends(User user) {

        List<List<Friendship>> friendships = getFriendshipSentReceived(user);
        List<Friendship> both = friendships.get(2);

        return both.stream().filter(friendship -> user.getId().equals(friendship.getId1())).toList();
    }

    public List<List<String>> findMessages(User userFrom, User userTo){

        List<Message> messages = (List<Message>) messageService.findAll();
        List<Message> usefull = messages.stream()
                .filter(message -> (message.getFrom().equals(userTo.getId())
                        && message.getTo().equals(userFrom.getId())) || (message.getFrom().equals(userFrom.getId())
                        && message.getTo().equals(userTo.getId()))).toList();

        List<String> from = new ArrayList<>();
        List<String> to = new ArrayList<>();

        for(Message m: usefull){
            if(m.getFrom().equals(userFrom.getId())) {
                from.add(m.getText());
                to.add("");
            }
            else
            {
                to.add(m.getText());
                from.add("");
            }
        }

        return List.of(from, to);
    }

    public void sendMessage(User userFrom, User userTo, String message) {

        messageService.save(List.of(message, userFrom.getId().toString(), userTo.getId().toString()));

    }
}
