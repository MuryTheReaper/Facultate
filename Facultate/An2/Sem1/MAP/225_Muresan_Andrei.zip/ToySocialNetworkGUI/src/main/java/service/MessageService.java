package service;

import domain.Message;
import repository.Repository;

import java.util.Collection;

public class MessageService extends BasicService<Long, Message> {

    public MessageService(Repository repository) {
        super(repository);
    }

    @Override
    public Long getNextId() {
        Collection<Message> all = (Collection<Message>) findTrueAll();
        Long max = 0L;
        for (Message entity : all) {
            if (entity.getId() > max )
                max = entity.getId();
        }
        return max+1;
    }
}
