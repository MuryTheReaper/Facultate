package service;

import domain.User;
import repository.Repository;

import java.util.Collection;

public class UserService extends BasicService<Long, User> {

    public UserService(Repository repository) {
        super(repository);
    }


    @Override
    public Long getNextId() {
        Collection<User> all = (Collection<User>) findTrueAll();
        Long max = 0L;
        for (User entity : all) {
            if (entity.getId() > max )
                max = entity.getId();
        }
        return max+1;
    }
}

