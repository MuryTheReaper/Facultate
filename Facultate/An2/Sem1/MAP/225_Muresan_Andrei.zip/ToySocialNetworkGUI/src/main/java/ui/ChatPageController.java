package ui;

import domain.Message;
import domain.User;
import domain.validators.ValidatorException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import repository.RepositoryException;
import service.MasterService;
import service.ServiceException;
import utils.SceneFactory;

import java.io.IOException;
import java.util.List;

public class ChatPageController {

    private MasterService service;

    private User fromUser;

    private User toUser;

    private ObservableList<String> fromMessages = FXCollections.observableArrayList();

    private ObservableList<String> toMessages = FXCollections.observableArrayList();

    @FXML
    Button sendButton;

    @FXML
    Button backButton;

    @FXML
    TextArea chatTxt;

    @FXML
    ListView<String> messagesFromList;

    @FXML
    ListView<String> messagesToList;

    @FXML
    public void initialize(){

        messagesFromList.setItems(fromMessages);
        messagesToList.setItems(toMessages);

    }

    public void setService(MasterService service){
        this.service = service;

        refresh();

    }

    public void refresh(){

        List<List<String>> messages = service.findMessages(fromUser, toUser);
        fromMessages.setAll(messages.get(0));
        toMessages.setAll(messages.get(1));

    }

    public void setFromUser(User fromUser){
        this.fromUser = fromUser;
    }

    public void setToUser(User toUser){
        this.toUser = toUser;
    }

    public void onBackButtonClicked() throws IOException {
        SceneFactory.setScene("/pages/mainPage.fxml", "Hello, " + fromUser.getFirstName() + "!", List.of(fromUser, service), backButton);
    }

    public void onSendButtonClicked(){

        try{

            service.sendMessage(fromUser, toUser, chatTxt.getText());

            refresh();


        }catch (ServiceException | RepositoryException | ValidatorException e){
            Alert warring = new Alert(Alert.AlertType.ERROR,
                    e.getMessage(), ButtonType.OK);
            warring.showAndWait();

            if(warring.getResult() == ButtonType.OK)
                warring.close();
        }

    }
}
