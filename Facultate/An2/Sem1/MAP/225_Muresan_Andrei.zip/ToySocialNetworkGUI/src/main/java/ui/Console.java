package ui;

import domain.validators.ValidatorException;
import repository.RepositoryException;
import service.MasterService;
import service.ServiceException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;


/**
 * Class that represents the console for the application.
 */
public class Console {

    MasterService masterService;

    BufferedReader reader = new BufferedReader(
            new InputStreamReader(System.in));

    public Console(MasterService masterService) {
        this.masterService = masterService;
    }

    /**
     * Prints the menu of the application.
     */
    public void menu(){

        System.out.println("0. Show all users");
        System.out.println("00: Show all friendships");
        System.out.println("1. Add user");
        System.out.println("2. Remove user");
        System.out.println("3. Update user");
        System.out.println("4. Add friendship");
        System.out.println("5. Remove friendship");
        System.out.println("6. Update friendship");
        System.out.println("7. Show number of communities");
        System.out.println("8. Show most sociable community");
        System.out.println("-1. Exit");

    }

    /**
     * Prints the all the users.
     */
    private void showAllUsers() {
        masterService.getAllUsers().forEach(System.out::println);
    }

    /**
     * Adds a user to the repository.
     */
    private void addUser() {
        try{
            System.out.println("Enter first name:");
            String firstName = reader.readLine();
            System.out.println("Enter last name:");
            String lastName = reader.readLine();
            masterService.addUser(firstName, lastName);
            System.out.println("User added successfully!");
        } catch (RepositoryException | IOException | ServiceException | UiException e) {
            System.out.println(e.getMessage());
        }
    }

    /**
     * Removes a user from the repository.
     */
    private void removeUser() {
        try{
            System.out.println("Enter first name:");
            String firstName = reader.readLine();
            System.out.println("Enter last name:");
            String lastName = reader.readLine();

            List<String> users = masterService.findPotentialUser(firstName, lastName);
            if (users.size() == 0) {
                System.out.println("No user found!");
            } else {
                System.out.println("Found users:");
                final int[] n = {1};
                users.forEach(user -> {
                    System.out.println(n[0] + ": " + user.split("\\|\\|")[0]);
                    n[0]++;
                });
                System.out.println("Which user you want to remove:");
                int id = Integer.parseInt(reader.readLine());

                masterService.removeUser(users.get(id-1).split("\\|\\|")[1]);
                System.out.println("User removed successfully!");
            }

        } catch (RepositoryException | IOException | ServiceException | UiException e) {
            System.out.println(e.getMessage());
        }
    }

    /**
     * Updates a user from the repository.
     */
    private void updateUser() {
        try{
            System.out.println("Enter first name:");
            String firstName = reader.readLine();
            System.out.println("Enter last name:");
            String lastName = reader.readLine();

            List<String> users = masterService.findPotentialUser(firstName, lastName);
            if (users.size() == 0) {
                System.out.println("No user found!");
            } else {
                System.out.println("Found users:");
                final int[] n = {1};
                users.forEach(user -> {
                    System.out.println(n[0] + ": " + user.split("\\|\\|")[0]);
                    n[0]++;
                });
                System.out.println("Which user you want to update:");
                int id = Integer.parseInt(reader.readLine());

                System.out.println("Enter new first name:");
                String newFirstName = reader.readLine();
                System.out.println("Enter new last name:");
                String newLastName = reader.readLine();

                masterService.updateUser(users.get(id-1).split("\\|\\|")[1], newFirstName, newLastName);
                System.out.println("User updated successfully!");
            }

        } catch (RepositoryException | IOException | ServiceException | UiException e) {
            System.out.println(e.getMessage());
        }
    }

    /**
     * Prints all the friendships.
     */
    private void showAllFriendships() {
        masterService.getAllFriendships().forEach(System.out::println);
    }

    /**
     * Reads the data for a friendship
     * @return the data for a friendship
     * @throws IOException if the data cant be read
     */
    private List<String> readFriendship() throws IOException {
            System.out.println("Enter first name for 1st user:");
            String firstFirstName = reader.readLine();
            System.out.println("Enter last name for 1st user:");
            String firstLastName = reader.readLine();

            System.out.println("Enter first name for 2nd user:");
            String secondFirstName = reader.readLine();
            System.out.println("Enter last name for 2nd user:");
            String secondLastName = reader.readLine();

        return List.of(firstFirstName, firstLastName, secondFirstName, secondLastName);
    }

    /**
     * Adds a friendship to the repository.
     */
    private void addFriendship() {
        try{
            List<String> users = readFriendship();
            masterService.addFriendship(List.of(users.get(0),users.get(1)), List.of(users.get(2),users.get(3)));
            System.out.println("Friendship added successfully!");
        } catch (RepositoryException | IOException | ServiceException | UiException e) {
            System.out.println(e.getMessage());
        }
    }

    /**
     * Removes a friendship from the repository.
     */
    private void removeFriendship() {
        try{
            List<String> users = readFriendship();
            masterService.removeFriendship(List.of(users.get(0),users.get(1)), List.of(users.get(2),users.get(3)));
            System.out.println("Friendship removed successfully!");
        } catch (RepositoryException | IOException | ServiceException | UiException e) {
            System.out.println(e.getMessage());
        }
    }

    /**
     * Updates a friendship from the repository.
     */
    private void updateFriendship() {
        try{
            List<String> users = readFriendship();

            System.out.println("Enter first name for new user:");
            String newFirstName = reader.readLine();
            System.out.println("Enter last name for new user:");
            String newLastName = reader.readLine();

            masterService.updateFriendship(List.of(users.get(0),users.get(1)), List.of(users.get(2),users.get(3)),
                    List.of(newFirstName, newLastName));

            System.out.println("Friendship updated successfully!");
        } catch (RepositoryException | IOException | ServiceException | UiException e) {
            System.out.println(e.getMessage());
        }
    }

    /**
     * Prints the number of communities.
     */
    private void showNumberOfCommunities() {
        System.out.println("Number of communities: " + masterService.getNumberOfCommunities());
    }

    /**
     * Prints the most sociable community.
     */
    private void showMostSociableCommunity() {
        System.out.println("Most sociable community:");
        masterService.getMostSociableCommunity().forEach(System.out::println);
    }

    /**
     * Method used for demos.
     */
    private void testing(){
        masterService.addUser("Ana", "Maria");
        masterService.addUser("Andrei", "Muresan");
        masterService.addFriendship(List.of("Ana", "Maria"), List.of("Andrei", "Muresan"));

        masterService.addUser("Maria", "Popescu");
        masterService.addUser("Mihai", "Popescu");
        masterService.addUser("Mihai", "Ionescu");
        masterService.addUser("Mihai", "Vasilescu");
        masterService.addFriendship(List.of("Maria", "Popescu"), List.of("Mihai", "Popescu"));
        masterService.addFriendship(List.of("Maria", "Popescu"), List.of("Mihai", "Ionescu"));
        masterService.addFriendship(List.of("Mihai", "Popescu"), List.of("Mihai", "Vasilescu"));

        masterService.removeUser("1");

        masterService.addUser("Aurel", "Popescu");
        masterService.addUser("Aurel", "Ionescu");
        masterService.addFriendship(List.of("Aurel", "Popescu"), List.of("Aurel", "Ionescu"));


        //masterService.addFriendship(List.of("Ana", "Maria"), List.of("Maria", "Popescu"));
    }

    /**
     * Runs the console.
     * @throws IOException if the command cant be read
     */
    public void run() throws IOException {
        while (true) {
            menu();
            System.out.println("Enter command: ");
            String command = reader.readLine();
            switch (command) {
                case "0":
                    showAllUsers();
                    break;
                case "00":
                    showAllFriendships();
                    break;
                case "1":
                    addUser();
                    break;
                case "2":
                    removeUser();
                    break;
                case "3":
                    updateUser();
                    break;
                case "4":
                    addFriendship();
                    break;
                case "5":
                    removeFriendship();
                    break;
                case "6":
                    updateFriendship();
                    break;
                case "7":
                    showNumberOfCommunities();
                    break;
                case "8":
                    showMostSociableCommunity();
                    break;
                case "-1":
                    return;
                default:
                    System.out.println("Invalid command");
            }
        }
    }
}
