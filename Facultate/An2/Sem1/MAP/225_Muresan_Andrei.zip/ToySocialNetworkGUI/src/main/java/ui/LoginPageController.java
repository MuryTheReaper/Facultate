package ui;

import domain.User;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import repository.RepositoryException;
import service.MasterService;
import javafx.scene.control.Alert;
import service.ServiceException;
import utils.SceneFactory;

import java.io.IOException;
import java.util.List;

public class LoginPageController {


    private MasterService service;

    @FXML
    TextField usernameTxt;

    @FXML
    TextField passwordTxt;

    @FXML
    Button loginButton;

    @FXML
    Button registerButton;

    @FXML
    Button closeButton;

    public void setService(MasterService service){
        this.service = service;
    }

    public void onLoginButtonClicked() throws IOException {

        try{

            User user = service.login(usernameTxt.getText(), passwordTxt.getText());
            SceneFactory.setScene("/pages/mainPage.fxml", "Hello, " + user.getFirstName() + "!", List.of(user, service), loginButton);

        }catch (ServiceException | RepositoryException e){
            Alert warring = new Alert(Alert.AlertType.ERROR,
                    e.getMessage(), ButtonType.OK);
            warring.showAndWait();

            if(warring.getResult() == ButtonType.OK)
                warring.close();
        }

    }

    public void onRegisterButtonClicked() throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/pages/registerPage.fxml"));
        Scene registerScene = new Scene(loader.load(), 600, 400);
        Stage registerStage = (Stage) registerButton.getScene().getWindow();
        RegisterPageController ctrl = loader.getController();
        ctrl.setService(service);
        registerStage.setScene(registerScene);
        registerStage.setTitle("Register Screen");
    }

    public void onCloseButtonClicked(){
        ((Stage) (closeButton.getScene().getWindow())).close();
    }

}
