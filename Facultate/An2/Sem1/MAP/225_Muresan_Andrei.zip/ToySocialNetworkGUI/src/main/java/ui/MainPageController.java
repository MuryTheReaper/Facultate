package ui;

import domain.Friendship;
import domain.Message;
import domain.User;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;

import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.util.Callback;
import repository.RepositoryException;
import service.MasterService;
import service.ServiceException;
import utils.Constants;
import utils.SceneFactory;

import java.io.IOException;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class MainPageController {

    private MasterService service;

    private User currentUser;

    private ObservableList<User> listUsers = FXCollections.observableArrayList();

    private ObservableList<Friendship> listFriends = FXCollections.observableArrayList();

    private ObservableList<Friendship> listRequests = FXCollections.observableArrayList();

    private List<User> users;

    @FXML
    Button logoutButton;

    @FXML
    Button friendRequestButton;

    @FXML
    TableView<User> usersTable;

    @FXML
    TableColumn<User, String> tableUsersColumnFirstName;

    @FXML
    TableColumn<User, String> tableUsersColumnLastName;

    @FXML
    TableView<Friendship> friendsTable;

    @FXML
    TableColumn<Friendship, String> tableFriendsColumnFirstName;

    @FXML
    TableColumn<Friendship, String> tableFriendsColumnLastName;

    @FXML
    TableView<Friendship> friendRequestsTable;

    @FXML
    TableColumn<Friendship, String> tableRequestsColumnFirstName;

    @FXML
    TableColumn<Friendship, String> tableRequestsColumnLastName;

    @FXML
    TableColumn<Friendship, String> tableRequestsColumnFrom;
    @FXML
    TableColumn<Friendship, String> tableRequestsColumnStatus;

    @FXML
    TextField firstNameTxt;

    @FXML
    TextField lastNameTxt;

    @FXML
    Button openChatButton;


    @FXML
    public void initialize() {

        tableUsersColumnFirstName.setCellValueFactory(new PropertyValueFactory<User, String>("firstName"));
        tableUsersColumnLastName.setCellValueFactory(new PropertyValueFactory<User, String>("lastName"));

        extractInfo(tableRequestsColumnFirstName, tableRequestsColumnLastName);
        tableRequestsColumnStatus.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Friendship, String>, ObservableValue<String>>() {
            @Override
            public ObservableValue<String> call(TableColumn.CellDataFeatures<Friendship, String> param) {
                User user1 = service.getUserById(param.getValue().getId1());

                if(Objects.equals(user1.getId(), currentUser.getId()))
                    return new javafx.beans.property.SimpleStringProperty("Sent");
                else
                    return new javafx.beans.property.SimpleStringProperty("Received");
            }
        });

        tableRequestsColumnFrom.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Friendship, String>, ObservableValue<String>>() {
            @Override
            public ObservableValue<String> call(TableColumn.CellDataFeatures<Friendship, String> param) {
                return new javafx.beans.property.SimpleStringProperty(param.getValue().getDate().format(Constants.formatter));
            }
        });

        extractInfo(tableFriendsColumnFirstName, tableFriendsColumnLastName);


        usersTable.setItems(listUsers);
        friendRequestsTable.setItems(listRequests);
        friendsTable.setItems(listFriends);
    }

    private void extractInfo(TableColumn<Friendship, String> tableRequestsColumnFirstName, TableColumn<Friendship, String> tableRequestsColumnLastName) {
        tableRequestsColumnFirstName.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Friendship, String>, ObservableValue<String>>() {
            @Override
            public ObservableValue<String> call(TableColumn.CellDataFeatures<Friendship, String> param) {
                User user1 = service.getUserById(param.getValue().getId1());
                User user2 = service.getUserById(param.getValue().getId2());

                if(Objects.equals(user1.getId(), currentUser.getId()))
                    return new javafx.beans.property.SimpleStringProperty(user2.getFirstName());
                else
                    return new javafx.beans.property.SimpleStringProperty(user1.getFirstName());

            }
        });
        tableRequestsColumnLastName.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Friendship, String>, ObservableValue<String>>() {
            @Override
            public ObservableValue<String> call(TableColumn.CellDataFeatures<Friendship, String> param) {
                User user1 = service.getUserById(param.getValue().getId1());
                User user2 = service.getUserById(param.getValue().getId2());

                if(Objects.equals(user1.getId(), currentUser.getId()))
                    return new javafx.beans.property.SimpleStringProperty(user2.getLastName());
                else
                    return new javafx.beans.property.SimpleStringProperty(user1.getLastName());

            }
        });
    }

    public void setService(MasterService service){

        this.service = service;
        users = (List<User>) service.getAllUsers();
        users.remove(currentUser);
        listUsers.setAll(users);

        refreshFriendRequests();
        refreshFriends();

        firstNameTxt.textProperty().addListener(observable -> listUsersHandler());
        lastNameTxt.textProperty().addListener(observable -> listUsersHandler());


    }

    private void refreshFriendRequests(){

        List<List<Friendship>> friendships = service.findFriendRequests(currentUser);
        List<Friendship> sent = friendships.get(0);
        List<Friendship> received = friendships.get(1);

        listRequests.setAll(received);
        listRequests.addAll(sent);
    }

    private void refreshFriends(){
        List<Friendship> friendships = service.findFriends(currentUser);
        listFriends.setAll(friendships);
    }

    public void setCurrentUser(User user){
        this.currentUser = user;
    }

    public void onLogoutButtonClicked() throws IOException {

        List<Object> params = List.of(service);
        SceneFactory.setScene("/pages/loginPage.fxml", "Login", List.of(service), logoutButton);
    }

    public void onFriendRequestButtonClicked() {

        try {

            User selectedUser = usersTable.getSelectionModel().getSelectedItem();

            if(selectedUser == null)
                throw new UiException("No user selected!");

            service.sendFriendRequest(currentUser, selectedUser);

            refreshFriendRequests();

        } catch (ServiceException | RepositoryException | UiException e) {
            Alert warring = new Alert(Alert.AlertType.ERROR,
                    e.getMessage(), ButtonType.OK);
            warring.showAndWait();

            if(warring.getResult() == ButtonType.OK)
                warring.close();
        }

    }

    private void listUsersHandler() {

        Predicate<User> p1 = u -> u.getFirstName().startsWith(firstNameTxt.getText());
        Predicate<User> p2 = u -> u.getLastName().startsWith(lastNameTxt.getText());

        listUsers.setAll(users
                .stream()
                .filter(p1.and(p2))
                .collect(Collectors.toList()));
    }

    public void onAcceptButtonClicked(){

        try {
            Friendship selectedRequest = friendRequestsTable.getSelectionModel().getSelectedItem();

            if (selectedRequest == null)
                throw new UiException("No request selected!");

            if (Objects.equals(selectedRequest.getId1(), currentUser.getId()))
                throw new UiException("You can't accept your own request!");

            service.acceptFriendRequest(service.getUserById(selectedRequest.getId1()), currentUser);
            refreshFriendRequests();
            refreshFriends();
        } catch (ServiceException | RepositoryException | UiException e) {
            Alert warring = new Alert(Alert.AlertType.ERROR,
                    e.getMessage(), ButtonType.OK);
            warring.showAndWait();

            if(warring.getResult() == ButtonType.OK)
                warring.close();
        }

    }

    public void onDenyButtonClicked(){

        try {
            Friendship selectedRequest = friendRequestsTable.getSelectionModel().getSelectedItem();

            if (selectedRequest == null)
                throw new UiException("No request selected!");

            if (Objects.equals(selectedRequest.getId1(), currentUser.getId()))
                throw new UiException("You can't deny your own request!");

            service.denyFriendRequest(selectedRequest);
            refreshFriendRequests();

        } catch (ServiceException | RepositoryException | UiException e) {
            Alert warring = new Alert(Alert.AlertType.ERROR,
                    e.getMessage(), ButtonType.OK);
            warring.showAndWait();

            if(warring.getResult() == ButtonType.OK)
                warring.close();
        }

    }

    public void onCancelButtonClicked(){

        try {
            Friendship selectedRequest = friendRequestsTable.getSelectionModel().getSelectedItem();

            if (selectedRequest == null)
                throw new UiException("No request selected!");

            if (Objects.equals(selectedRequest.getId2(), currentUser.getId()))
                throw new UiException("You cancel requests that are not yours!");

            service.denyFriendRequest(selectedRequest);
            refreshFriendRequests();

        } catch (ServiceException | RepositoryException | UiException e) {
            Alert warring = new Alert(Alert.AlertType.ERROR,
                    e.getMessage(), ButtonType.OK);
            warring.showAndWait();

            if(warring.getResult() == ButtonType.OK)
                warring.close();
        }

    }

    public void onRemoveFriendButtonClicked(){

        try {
            Friendship selectedFriend = friendsTable.getSelectionModel().getSelectedItem();

            if (selectedFriend == null)
                throw new UiException("No friend selected!");

            User user2 = service.getUserById(selectedFriend.getId2());

            service.removeFriendship(List.of(currentUser.getFirstName(), currentUser.getLastName()), List.of(user2.getFirstName(), user2.getLastName()));
            refreshFriends();

        } catch (ServiceException | RepositoryException | UiException e) {
            Alert warring = new Alert(Alert.AlertType.ERROR,
                    e.getMessage(), ButtonType.OK);
            warring.showAndWait();

            if(warring.getResult() == ButtonType.OK)
                warring.close();
        }

    }

    public void onOpenChatButtonClicked() throws IOException {

        try {
            Friendship selectedFriend = friendsTable.getSelectionModel().getSelectedItem();

            if (selectedFriend == null)
                throw new UiException("No friend selected!");

            User user2 = service.getUserById(selectedFriend.getId2());

            SceneFactory.setScene("/pages/chatPage.fxml", "Chat", List.of(currentUser, user2, service), openChatButton);
        } catch (ServiceException | RepositoryException | UiException e) {
            Alert warring = new Alert(Alert.AlertType.ERROR,
                    e.getMessage(), ButtonType.OK);
            warring.showAndWait();

            if(warring.getResult() == ButtonType.OK)
                warring.close();
        }

    }
}
