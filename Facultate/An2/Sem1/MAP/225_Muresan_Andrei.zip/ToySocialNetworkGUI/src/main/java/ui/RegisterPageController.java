package ui;

import domain.validators.ValidatorException;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import repository.RepositoryException;
import service.MasterService;
import service.ServiceException;

import java.io.IOException;

public class RegisterPageController {

    @FXML
    TextField usernameTxt;

    @FXML
    TextField passwordTxt;

    @FXML
    TextField firstNameTxt;

    @FXML
    TextField lastNameTxt;

    @FXML
    Button registerButton;

    @FXML
    Button closeButton;

    MasterService service;

    public void setService(MasterService service){
        this.service = service;
    }

    public void onRegisterButtonClicked() throws IOException {

        try {
            service.registerUser(usernameTxt.getText(), passwordTxt.getText(), firstNameTxt.getText(), lastNameTxt.getText());
            Alert alert = new Alert(Alert.AlertType.INFORMATION,
                    "User registered successfully", ButtonType.OK);
            alert.showAndWait();

            if(alert.getResult() == ButtonType.OK)
                alert.close();

            onCloseButtonClicked();


        } catch (ServiceException | RepositoryException | UiException e) {
            Alert warring = new Alert(Alert.AlertType.ERROR,
                    e.getMessage(), ButtonType.OK);
            warring.showAndWait();

            if(warring.getResult() == ButtonType.OK)
                warring.close();
        }

    }

    public void onCloseButtonClicked() throws IOException {

        FXMLLoader loader = new FXMLLoader(getClass().getResource("/pages/loginPage.fxml"));
        Scene loginScene = new Scene(loader.load(), 600, 400);
        Stage loginStage = (Stage) closeButton.getScene().getWindow();
        LoginPageController ctrl = loader.getController();
        ctrl.setService(service);
        loginStage.setScene(loginScene);
        loginStage.setTitle("Login Screen");

    }





}
