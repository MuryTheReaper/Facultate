package utils;

import java.util.ArrayList;
import java.util.List;

/**
 * Class that represents a graph.
 */
public class Graph {
    private final int V; // No. of vertices in graph.

    private final List<Integer>[] adj; // Adjacency List
    // representation

    public Graph(int v)
    {
        V = v;
        adj = new List[v];

        for (int i = 1; i < v; i++)
            adj[i] = new ArrayList<>();
    }

    /**
     * Function to add an edge into the graph
     * @param u - the first vertex
     * @param w - the second vertex
     */
    public void addEdge(int u, int w)
    {
        adj[u].add(w);
        //adj[w].add(u); // Undirected Graph.
    }

    /**
     * Function to get a connected component of the graph
     * @param v - starting the vertex
     * @param visited - the visited vertices
     * @param al - the list of vertices in the connected component
     */
    private void DFSUtil(int v, boolean[] visited, ArrayList<Integer> al)
    {
        visited[v] = true;
        al.add(v);
        for (int n : adj[v]) {
            if (!visited[n])
                DFSUtil(n, visited, al);
        }
    }

    /**
     * Function to get all connected components
     * @return - a list of lists of vertices
     */
    public ArrayList<ArrayList<Integer>> DFS()
    {
        ArrayList<ArrayList<Integer> > components
                = new ArrayList<>();
        boolean[] visited = new boolean[V];
        for (int i = 1; i < V; i++) {
            ArrayList<Integer> al = new ArrayList<>();
            if (!visited[i]) {
                DFSUtil(i, visited, al);
                components.add(al);
            }
        }
        return components;
    }

    /**
     * Function to get the longest path in the graph
     * @return - the length of the longest path
     */
    public int getLongestPath() {

        boolean[] visited = new boolean[V];
        int[] dist = new int[V];

        int max = 0;

        for (int i = 1; i < V; i++) {
            if (!visited[i]) {
                dfs(i, visited, dist);
                for (int j = 1; j < V; j++) {
                    visited[j] = false;
                    max = Math.max(max, dist[j]);
                    dist[j] = 0;
                }
            }
        }

        return max;
    }

    /**
     * Function to get distance from a vertex to all other vertices
     * @param u - the starting vertex
     * @param visited - the visited vertices
     * @param dist - the distance from the starting vertex to all other vertices
     */
    private void dfs(int u, boolean[] visited, int[] dist) {
        visited[u] = true;
        for (int v : adj[u]) {
            if (!visited[v]) {
                dist[v] = dist[u] + 1;
                dfs(v, visited, dist);
            }
        }
    }

    public int getNumberOfConnectedComponents() {
        return DFS().size();
    }
}