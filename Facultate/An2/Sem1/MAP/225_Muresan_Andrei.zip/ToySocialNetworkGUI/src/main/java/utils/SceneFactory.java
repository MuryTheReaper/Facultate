package utils;

import domain.User;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import service.MasterService;
import ui.ChatPageController;
import ui.LoginPageController;
import ui.MainPageController;

import java.io.IOException;
import java.util.List;

public class SceneFactory {

    private static SceneFactory singleton = null;

    private SceneFactory() {
    }

    public synchronized static SceneFactory getInstance() {
        if (singleton == null) {
            singleton = new SceneFactory();
        }
        return singleton;
    }

    public static void setScene(String path, String title, List<Object> params, Button button) throws IOException {

        FXMLLoader loader = new FXMLLoader(SceneFactory.class.getResource(path));
        Scene scene = new Scene(loader.load(), 600, 400);
        Stage stage = (Stage) button.getScene().getWindow();

        switch (path) {
            case "/pages/loginPage.fxml" -> {
                LoginPageController ctrl = loader.getController();
                ctrl.setService((MasterService) params.get(0));
            }
            case "/pages/mainPage.fxml" -> {
                MainPageController ctrl = loader.getController();
                ctrl.setCurrentUser((User) params.get(0));
                ctrl.setService((MasterService) params.get(1));
            }
            case "/pages/chatPage.fxml" -> {
                ChatPageController ctrl = loader.getController();
                ctrl.setFromUser((User) params.get(0));
                ctrl.setToUser((User) params.get(1));
                ctrl.setService((MasterService) params.get(2));
            }
        }

        stage.setScene(scene);
        stage.setTitle(title);


    }
}
